package com.example.practical_8_recievingamessagealert;

public class SecondActivity {
}
